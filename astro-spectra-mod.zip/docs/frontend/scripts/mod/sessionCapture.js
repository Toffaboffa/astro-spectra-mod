// sessionCapture.js
// Capture snapshots/metadata for batch exports.
