// SPECTRA-PRO: reproducible observation profile
// Mode, preset, subtraction state, overlays, timestamps and source notes.
export function buildObservationProfile(){ return {}; }
