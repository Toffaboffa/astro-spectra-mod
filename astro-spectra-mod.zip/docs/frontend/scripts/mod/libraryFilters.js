// libraryFilters.js
// Translate UI filters to worker filter payloads.
