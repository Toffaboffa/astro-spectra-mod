// exportAugment.js
// Augment SPECTRA exports with mod metadata and IDs.
