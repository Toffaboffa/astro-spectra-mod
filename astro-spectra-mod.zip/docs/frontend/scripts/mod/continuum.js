// continuum.js
// Continuum estimation + normalization for solar/stellar spectra.
