// SPECTRA-PRO: instrument response correction
// Creates/applies camera+spectrometer response profiles (white-light / flat-like correction).
export function applyInstrumentResponse(frame){ return frame; }
