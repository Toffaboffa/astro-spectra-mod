// SPECTRA-PRO: calibration import/export helpers
// Parses txt/csv calibration point files and serializes user calibration sets.
export function parseCalibrationFile(text){ return []; }
