// normalization.js
// Intensity normalization strategies (max/channel/luminance).
