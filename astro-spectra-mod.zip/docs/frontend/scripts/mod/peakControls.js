// SPECTRA-PRO: Peak control bridge
// Keeps visual peak settings separate from worker analysis peak settings (distance/threshold/smoothing).
export function getPeakControlState(){ return {}; }
