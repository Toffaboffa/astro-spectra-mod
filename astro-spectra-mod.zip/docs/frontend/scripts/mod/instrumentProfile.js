// SPECTRA-PRO: reproducible instrument profile
// Camera, stripe defaults, calibration, response correction and hardware notes.
export function buildInstrumentProfile(){ return {}; }
