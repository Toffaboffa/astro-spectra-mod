// SPECTRA-PRO: browser camera capability abstraction
// Normalizes exposure/gain/torch/low-light support and reports unsupported states cleanly.
export async function probeCameraCapabilities(){ return {}; }
