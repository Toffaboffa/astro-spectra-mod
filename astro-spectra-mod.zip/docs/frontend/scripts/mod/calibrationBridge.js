// calibrationBridge.js
// Read/write calibration state from original calibrationScript globals.
