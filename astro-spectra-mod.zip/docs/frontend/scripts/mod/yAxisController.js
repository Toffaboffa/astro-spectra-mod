// SPECTRA-PRO: y-axis scaling controller
// Supports AUTO, FIXED_255, and later MANUAL. Integrates with graphScript hook.
export const Y_AXIS_MODES = ['AUTO','FIXED_255','MANUAL'];
