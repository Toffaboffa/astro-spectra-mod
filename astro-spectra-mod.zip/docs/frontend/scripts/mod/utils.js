// utils.js
// Shared helpers: clamp, debounce, format nm, stats.
