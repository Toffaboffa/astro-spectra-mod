// SPECTRA-PRO: local response profile storage
// Stores versioned response profiles per camera/spectrometer combo in localStorage (later IndexedDB).
export const RESPONSE_PROFILE_SCHEMA_VERSION = 1;
