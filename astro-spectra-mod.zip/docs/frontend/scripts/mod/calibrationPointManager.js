// SPECTRA-PRO: multipoint calibration manager
// Supports enable/disable points, outlier marking, sorting, and residual annotations.
export function createCalibrationPointManager(){ return {}; }
