// SPECTRA-PRO: graph appearance settings
// Handles graph fill mode: OFF / SYNTHETIC / REAL_SAMPLED and opacity.
export function applyGraphAppearance(){ /* placeholder */ }
