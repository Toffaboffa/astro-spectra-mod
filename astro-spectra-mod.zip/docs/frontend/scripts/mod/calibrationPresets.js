// calibrationPresets.js
// Preset loading for Hg/Ne/Ar/Solar/H-alpha rigs.
