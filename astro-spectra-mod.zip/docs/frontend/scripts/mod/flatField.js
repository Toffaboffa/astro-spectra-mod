// flatField.js
// Instrument response/flat correction support.
