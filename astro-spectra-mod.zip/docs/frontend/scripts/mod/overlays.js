// overlays.js
// Draw labels, markers, band spans, confidence badges on graph canvas.
