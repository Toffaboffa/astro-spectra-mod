// smoothing.js
// Median / SG-lite smoothing filters.
