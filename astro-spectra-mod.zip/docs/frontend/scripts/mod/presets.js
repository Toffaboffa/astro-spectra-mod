// presets.js
// High-level mode presets (Lab, Sun, Star, Planet, DeepSky).
