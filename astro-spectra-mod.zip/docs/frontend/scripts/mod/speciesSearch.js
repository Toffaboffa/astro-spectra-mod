// speciesSearch.js
// Autocomplete and species lookup (atoms/ions/molecules).
