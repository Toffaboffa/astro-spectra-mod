// offsetEstimate.js
// Robust wavelength offset estimate across candidate lines.
