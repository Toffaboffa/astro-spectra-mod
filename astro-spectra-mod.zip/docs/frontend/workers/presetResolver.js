// presetResolver.js
// Resolve preset config into worker analysis settings.
