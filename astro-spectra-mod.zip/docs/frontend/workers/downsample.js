// downsample.js
// Downsample arrays for analysis tick speed.
