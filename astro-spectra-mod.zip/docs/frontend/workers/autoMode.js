// autoMode.js
// Emission/absorption auto-choice heuristics.
