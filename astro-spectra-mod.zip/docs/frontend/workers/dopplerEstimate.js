// dopplerEstimate.js
// Convert offset(s) to RV estimate with quality flag.
