// bandMatcher.js
// Coarse molecular band/bandhead matching.
