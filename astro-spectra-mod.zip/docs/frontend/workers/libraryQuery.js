
(function (root) {
  'use strict';
  function queryByRange(index, minNm, maxNm) {
    return [];
  }
  root.SPECTRA_PRO_libraryQuery = { queryByRange };
})(typeof self !== 'undefined' ? self : this);
