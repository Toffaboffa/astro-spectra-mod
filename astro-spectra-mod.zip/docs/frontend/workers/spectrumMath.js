// spectrumMath.js
// Core numeric helpers (normalize, invert, derivative, windows).
